../../../lib/xaxivdma_channel.o: xaxivdma_channel.c xaxivdma_hw.h \
 ../../../include/xil_types.h ../../../include/bspconfig.h \
 ../../../include/xparameters.h ../../../include/xil_io.h \
 ../../../include/xil_types.h ../../../include/xil_printf.h \
 ../../../include/xstatus.h ../../../include/xil_assert.h \
 ../../../include/mb_interface.h ../../../include/xil_exception.h \
 xaxivdma_i.h ../../../include/xdebug.h ../../../include/xstatus.h \
 xaxivdma.h ../../../include/xil_assert.h
xaxivdma_hw.h:
../../../include/xil_types.h:
../../../include/bspconfig.h:
../../../include/xparameters.h:
../../../include/xil_io.h:
../../../include/xil_types.h:
../../../include/xil_printf.h:
../../../include/xstatus.h:
../../../include/xil_assert.h:
../../../include/mb_interface.h:
../../../include/xil_exception.h:
xaxivdma_i.h:
../../../include/xdebug.h:
../../../include/xstatus.h:
xaxivdma.h:
../../../include/xil_assert.h:
