../../../lib/xvtc_g.o: xvtc_g.c ../../../include/xparameters.h xvtc.h \
 xvtc_hw.h ../../../include/xil_io.h ../../../include/xil_types.h \
 ../../../include/bspconfig.h ../../../include/xparameters.h \
 ../../../include/xil_printf.h ../../../include/xstatus.h \
 ../../../include/xil_assert.h ../../../include/mb_interface.h \
 ../../../include/xil_exception.h ../../../include/xil_assert.h \
 ../../../include/xstatus.h
../../../include/xparameters.h:
xvtc.h:
xvtc_hw.h:
../../../include/xil_io.h:
../../../include/xil_types.h:
../../../include/bspconfig.h:
../../../include/xparameters.h:
../../../include/xil_printf.h:
../../../include/xstatus.h:
../../../include/xil_assert.h:
../../../include/mb_interface.h:
../../../include/xil_exception.h:
../../../include/xil_assert.h:
../../../include/xstatus.h:
